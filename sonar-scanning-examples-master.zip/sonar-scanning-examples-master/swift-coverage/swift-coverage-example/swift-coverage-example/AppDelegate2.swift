//
//  AppDelegate2.swift
//  swift-coverage-example
//
//  Created by Alexandre Gigleux on 30.04.18.
//  Copyright © 2018 SonarSource. All rights reserved.
//


class AB {
    func foo(){
        if (1 > 2) {
            print("hello")
        } else {
            print("Bye")
        }
    }
}
